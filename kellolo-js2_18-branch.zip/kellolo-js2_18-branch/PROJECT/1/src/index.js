import './layout/css/style.css'
import './layout/css/normalize.css'

import app from './components/main.js'

app();