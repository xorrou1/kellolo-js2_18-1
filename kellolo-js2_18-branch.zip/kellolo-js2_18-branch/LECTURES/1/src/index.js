import app from './components/main.js';

app();
