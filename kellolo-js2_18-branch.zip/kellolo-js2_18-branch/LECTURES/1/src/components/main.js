import compFunction from './component.js';

let name = prompt('Enter your name');

export default function() {
    compFunction(name);
};
