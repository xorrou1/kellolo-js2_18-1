export default function(userName) {
    console.log(`Hello ${userName}`);
};